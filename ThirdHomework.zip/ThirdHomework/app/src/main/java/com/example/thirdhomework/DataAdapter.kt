package com.example.thirdhomework

class DataAdapter : RecyclerV{
}