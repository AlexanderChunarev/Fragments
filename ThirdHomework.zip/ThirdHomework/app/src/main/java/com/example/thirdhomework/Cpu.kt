package com.example.thirdhomework

class Cpu(var name: String?, var description: String?, var image: Int)